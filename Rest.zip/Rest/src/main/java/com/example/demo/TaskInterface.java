package com.example.demo;

import java.sql.SQLException;
import java.util.List;

public interface TaskInterface {
	public List<Task> getTasks();
	public List <Task>getAllTasks();
	public Task addTask(Task task);

	public int setpriority(int taskID, String Priority);

    public	int setBookMark(int taskID, boolean isBookmarked) throws SQLException ;

	public int setNotes(int taskID, String notes) throws SQLException; 
    
	public int assignTask(int taskID,int userid) throws SQLException;
	
	public int search(int taskID) throws SQLException;

}
