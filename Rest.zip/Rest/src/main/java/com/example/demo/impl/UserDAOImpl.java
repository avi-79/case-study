package com.example.demo.impl;

import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import com.example.demo.UserDao;
import com.example.demo.DbConnection;
import com.example.demo.User;
@Component
public class UserDAOImpl implements UserDao{
	int row = 0;
	DbConnection db = new DbConnection();
	User user =null;

	@Override
	public int save(Object object) {
		try {
			user = (User)object;
			PreparedStatement ps = db.getConnection().prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?,?)");
		
			ps.setInt(1,user.getUserid());
			ps.setString(2, user.getUsername());
			ps.setString(3,user.getFirstNAME());
			ps.setString(4, user.getLASTNAME());
			ps.setLong(5,user.getCONTACT_NUMBER());
			ps.setString(6, user.getROLE());
			ps.setBoolean(7,user.isIsActive());
			ps.setString(8, user.getDOB());
		    ps.setString(9,user.getCreated_On());
	
			ps.setString(10,user.getEMAIL());
			
			row = ps.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {System.out.println(e);}
		return row;
	}


	private Timestamp valueOf(LocalDateTime now) {
		// TODO Auto-generated method stub
		return null;
	}


	//@Override
	public List<User> getData() {
		List<User> userlist = new ArrayList<>();
		try {
			PreparedStatement ps1 = db.getConnection().prepareStatement("select * from user");
			ResultSet rs = ps1.executeQuery();
			while(rs.next()) {
			User u = new User();
			int userid = rs.getInt(1);
			String username = rs.getString(2);
			String fname = rs.getString(3);
			String lname = rs.getString(4);
			long contactno = rs.getLong(5);
			String role = rs.getString(6);
			boolean isactive = rs.getBoolean(7);
			String dob = rs.getString(8);
			String Created_On=rs.getString(9);
			String EMAIL=rs.getString(10);
			
			u.setUserid(userid);
			u.setUsername(username);
			u.setFirstNAME(fname);
			u.setLASTNAME(lname);
			u.setCONTACT_NUMBER(contactno);
			u.setROLE(role);
			u.setIsActive(isactive);
			u.setDOB(dob);
			u.setCreated_On(Created_On);
			u.setEMAIL(EMAIL);
			
			userlist.add(u);}
		}catch(SQLException se) {se.printStackTrace();}
           return userlist;
     }
	@Override
	public int update(Object object) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public User adduser(User u)  throws SQLException{
		try{
			user = (User)user;
			PreparedStatement psu = db.getConnection().prepareStatement("insert into user values(?,?,?,?,?,?,?,?,?,?)");

			psu.setInt(1,user.getUserid());
			psu.setString(2, user.getUsername());
			psu.setString(3,user.getFirstNAME());
			psu.setString(4, user.getLASTNAME());
			psu.setLong(5,user.getCONTACT_NUMBER());
			psu.setString(6, user.getROLE());
			psu.setBoolean(7,user.isIsActive());
			psu.setString(8, user.getDOB());
		    psu.setString(9,user.getCreated_On());
	
			psu.setString(10,user.getEMAIL());
			
			row = psu.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {System.out.println(e);
		}
		return user;
	}	
	}