package com.example.demo.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.Task;
import com.example.demo.TaskInterface;
import com.example.demo.DbConnection;

@Component
public class Taskimpl implements TaskInterface {

	
	@Autowired
	DbConnection db;
	int row=0;
	@Override
	public List<Task> getTasks()
	{
		List<Task> tlist = new ArrayList<>();
			try {
				PreparedStatement ps1 = db.getConnection().prepareStatement("select * from task");
				ResultSet rs = ps1.executeQuery();
				while(rs.next()) {
					Task t1 = new Task();
			    t1.setTaskID(rs.getInt(1));
			    t1.setOwnerID(rs.getInt(2));
			    t1.setCreatorID(rs.getInt(3));
			    t1.setName(rs.getString(4));
			    t1.setDescription(rs.getString(5));
			    t1.setStatus(rs.getString(6));
			    t1.setPriority(rs.getString(7));
			    t1.setName(rs.getString(8));;
			    t1.setIsBookmarked(rs.getBoolean(9));
			    t1.setCreatedOn(rs.getString(10));
			    t1.setStatusChangedOn(rs.getString(11));
			    tlist.add(t1);
			   
			   }
			}catch(SQLException se) {se.printStackTrace();}
	        return tlist;
	        }
	@Override
	public List<Task> getAllTasks()
	{
		List<Task> tlist = new ArrayList<>();
			try {
				PreparedStatement ps1 = db.getConnection().prepareStatement("select * from task");
				ResultSet rs = ps1.executeQuery();
				while(rs.next()) {
					Task t1 = new Task();
			    t1.setTaskID(rs.getInt(1));
			    t1.setOwnerID(rs.getInt(2));
			    t1.setCreatorID(rs.getInt(3));
			    t1.setName(rs.getString(4));
			    t1.setDescription(rs.getString(5));
			    t1.setStatus(rs.getString(6));
			    t1.setPriority(rs.getString(7));
			    t1.setName(rs.getString(8));;
			    t1.setIsBookmarked(rs.getBoolean(9));
			    t1.setCreatedOn(rs.getString(10));
			    t1.setStatusChangedOn(rs.getString(11));
			    tlist.add(t1);
			   
			   }
			}catch(SQLException se) {se.printStackTrace();}
	        return tlist;
	        }

	@Override
	public int setpriority(int taskID, String priority) {
		try {
			 
			 PreparedStatement ps = db.getConnection().prepareStatement("update task set priority = ? where task_id = ?");
			 ps.setString(1, priority);
			 ps.setInt(2, taskID);
			 row = ps.executeUpdate();
			 db.closeConnection();
			 
		 }catch(SQLException sqe) {sqe.printStackTrace();}
		 
		return row;

	}
	
	public Task addTask(Task task)  {
		try {
			 PreparedStatement ps = db.getConnection().prepareStatement("Insert into task values(?,?,?,?,?,?,?,?,?,?,?)");
			 ps.setInt(1, task.getTaskID());
			 ps.setInt(2, task.getOwnerID());
			 ps.setInt(3, task.getCreatorID());
			 ps.setString(4, task.getName());
			 ps.setString(5, task.getDescription());
			 ps.setString(6, task.getStatus());
			 ps.setString(7, task.getPriority());
			 ps.setString(8, task.getNotes());
			 ps.setBoolean(9, task.getIsBookmarked());
			 ps.setString(10, task.getCreatedOn());
			 ps.setString(11, task.getStatusChangedOn());
			 row = ps.executeUpdate();
			 db.closeConnection();
		}catch(SQLException e) {System.out.println(e);}
		
		return task;
		
	}

	@Override
	public int setBookMark(int taskID,boolean isBookmarked) throws SQLException
	{
		PreparedStatement psu = db.getConnection().prepareStatement("update task  set IsBookmarked = ? where task_id=?");
		psu.setBoolean(1,isBookmarked);
		psu.setInt(2,taskID);
		 row = psu.executeUpdate();
		  return row;		
	}
	@Override
	public int setNotes(int taskID, String notes) throws SQLException{
    PreparedStatement psu1 = db.getConnection().prepareStatement("update task  set notes = ? where task_id=?");
		      psu1.setString(1,notes);
			psu1.setInt(2,taskID);
			 row = psu1.executeUpdate();
			  return row;		
		
	
	}
     
	@Override
	public int assignTask(int taskID, int ownerid) throws SQLException{
		 PreparedStatement p1 = db.getConnection().prepareStatement("update task assignTask ownerid = ? where task_id=?");
		p1.setInt(1,ownerid);
		p1.setInt(2, taskID);
		row = p1.executeUpdate();
		  return row;
	}

	@Override
	public int search(int taskID) throws SQLException {
		 PreparedStatement p1 = db.getConnection().prepareStatement("update task search  task_id=?");
			
			p1.setInt(1, taskID);
			row = p1.executeUpdate();
			  return row;

	}

	public int settrack(String status) throws SQLException {
		 PreparedStatement p1 = db.getConnection().prepareStatement("update task status where task_id=?");
			p1.setString(1,status);
			row = p1.executeUpdate();
			  return row;
		
	}
	

}
	

	
			
			
