
package com.example.demo;

public interface AdditionInterface {
	public int add(int x, int y);
}
