package com.example.demo;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.impl.Taskimpl;
import com.example.demo.impl.UserDAOImpl;



@RestController
public class RESTController {
	
	

	@Autowired
	Task tk;
	
	@Autowired
	Taskimpl dao;
	
	@Autowired
	UserDAOImpl user;
	
	
	//POST -as a portal admin ,i should create a task
	@PostMapping(value= "/addtask", consumes = "application/json", produces = "application/json")
	public Task addTask(@RequestBody Task task) throws Exception
	{
	   tk.addTask(task);
	   return task;

	}
	//POST -CREATE A USER
	@PostMapping(value= "/adduser", consumes = "application/json", produces = "application/json")
		public User addUser(@RequestBody User u) throws SQLException{
		user.adduser(u);
		return u;
	}
  //GET-As portal admin ,I should able to assign task to the team member
	@RequestMapping(value="/assignTask/{taskid}/taskid/{taskid}",method = RequestMethod.GET,produces = {"application/json","application/xml"})
	public List<Task> assignTask(@PathVariable int taskID,@PathVariable int userid,Model model) throws SQLException{
		int dao2 =dao.assignTask(taskID,userid);
		return dao.getTasks();
	}
	//Get As a admin, I should be able to prioritize tasks (taskid, priority)
	@RequestMapping(value="/taskid/{taskid}/priority/{priority}",method = RequestMethod.GET,produces = {"application/json","application/xml"})
	public List<Task> printTask(@PathVariable("taskid") int taskID, @PathVariable("priority") String priority, Model model) {
		model.addAttribute("taskid", taskID);
		model.addAttribute("priority", priority);
		int row = dao.setpriority(taskID, priority);
		return dao.getTasks();
	}
	
	//GET - As a admin, I should be able to add internal notes (taskid, notes)
	@RequestMapping(value="/taskid/{taskid}/notes/{notes}",method = RequestMethod.GET,produces = {"application/json","application/xml"})
	public List<Task> setNotes(@PathVariable int taskID, @PathVariable String notes) throws SQLException{
	int dao2 =dao.setNotes(taskID,notes);
	return dao.getAllTasks();
	}
	
	
	//GET - As a admin, I should be able to add bookmark (taskid, bookmark)
	@RequestMapping(value="/taskid/{taskid}/bookmark/{isBookMarked}",method = RequestMethod.GET,produces = {"application/json","application/xml"})
	public List<Task> setBookMark(@PathVariable("taskid") int taskID, @PathVariable boolean isBookMarked) throws SQLException {
	int dao1 =dao.setBookMark(taskID,isBookMarked);
	return dao.getAllTasks();
	
	}
	
	
	//GET - As a admin, I should be able to gat all tasks
	@RequestMapping(value = "/gettasks", method = RequestMethod.GET,produces = {"application/json","application/xml"})
	public List<Task> getTask() {
		return dao.getAllTasks();
	}
    
	
	//GET - As a admin, I should be able to searching tasks easier (taskid)
	
	@RequestMapping(value="/searchtasks",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public List<Task> setsearch(@PathVariable("taskid") int taskID) throws SQLException {
		int row=dao.search(taskID);
		return dao.getAllTasks();
	}
	
	//GET -As a admin, I should be able to track completion of all tasks (status)
	
	@RequestMapping(value="/settrack",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public List<Task> settrack(@PathVariable("taskid") String status) throws SQLException {
		int row=dao.settrack(status);
		return dao.getAllTasks();
	}


}
