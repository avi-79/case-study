package com.example.demo;


	import java.sql.SQLException;
import java.util.List;
	import com.example.demo.User;
	public interface UserDao {
	public int save(Object object);
     public List<User> getData();
	 public int update(Object object);
	 public User adduser(User u) throws SQLException;
	 




}
