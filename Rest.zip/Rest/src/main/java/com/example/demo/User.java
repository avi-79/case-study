package com.example.demo;
import java.security.Timestamp;
import java.sql.Date;
import java.time.LocalDateTime;


public class User {
	private int userid;
	private String Username;
	private String FirstNAME;
	private String  LASTNAME;
	private long  CONTACT_NUMBER;
	private String  ROLE; 
	private boolean IsActive;
	private String DOB;
	private String Created_On;
	private String EMAIL;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getFirstNAME() {
		return FirstNAME;
	}
	public void setFirstNAME(String firstNAME) {
		FirstNAME = firstNAME;
	}
	public String getLASTNAME() {
		return LASTNAME;
	}
	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}
	public long getCONTACT_NUMBER() {
		return CONTACT_NUMBER;
	}
	public void setCONTACT_NUMBER(long cONTACT_NUMBER) {
		CONTACT_NUMBER = cONTACT_NUMBER;
	}
	public String getROLE() {
		return ROLE;
	}
	public void setROLE(String rOLE) {
		ROLE = rOLE;
	}
	public boolean isIsActive() {
		return IsActive;
	}
	public void setIsActive(boolean isActive) {
		IsActive = isActive;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dob2) {
		DOB = dob2;
	}
	public String getCreated_On() {
		return Created_On;
	}
	public void setCreated_On(String timestamp) {
		Created_On = timestamp;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	
	public Object valueOf(LocalDateTime now) {
		// TODO Auto-generated method stub
		return null;
	}
	public void setTimestramp(Object valueOf) {
		// TODO Auto-generated method stub
		
	}
	public void setCreated_On(java.sql.Timestamp timestamp) {
		// TODO Auto-generated method stub
		
	}
	
}		
	


